<footer>
<div class="container-fluid">
	
<div class="row ">
	<div class="col-md-4 datos">
		<h1>Datos de contacto</h1>
		<p>
			<i class="fa fa-envelope fa-2x"></i>
			<a href="mailto:ejemplo@ejemplo.cl">ejemplo@ejemplo.cl</a>
		</p>
		<p>
			<i class="fa fa-mobile fa-2x"></i>
			+56 9 87654321
		</p>
		<p>
			<i class="fa fa-map-marker fa-2x"></i>
			Av. brasil 314. La Serena.
		</p>
	</div>

	<div class="col-md-4 colaboradores">
		<h1>Colaboradores del sitio.</h1>

		<div class="col-md-6 col-xs-6">
			<i class="fa fa-picture-o fa-4x"></i>
			<address>
				  <strong>Twitter, Inc.</strong><br>
				  795 Folsom Ave, Suite 600<br>
				  San Francisco, CA 94107<br>
				  <abbr title="Phone">P:</abbr> (123) 456-7890
				</address>
		</div>
		<div class="col-md-6 col-xs-6">
			<i class="fa fa-picture-o fa-4x"></i>
			<address>
				  <strong>Twitter, Inc.</strong><br>
				  795 Folsom Ave, Suite 600<br>
				  San Francisco, CA 94107<br>
				  <abbr title="Phone">P:</abbr> (123) 456-7890
				</address>
		</div>
	</div>

	<div class="col-md-4 inforSocial">
		<h1>Quiero recibir informacion.</h1>
		<div class="col-md-12">
			<form action="#" method="POST" class="form-inline form-info" role="form">
			
				<div class="form-group">
					<label class="sr-only" for="">email</label>
					<input type="email" class="form-control" id="txtemail" class="input-lg" placeholder="Example@example.com">
				</div>			
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>
		</div>
		<div class="col-md-12">
			<h2>Siguenos <small>en las redes sociales</small></h2>
			<i class="fa fa-css3 fa-3x"></i>
			<i class="fa fa-html5 fa-3x"></i>
			<i class="fa fa-facebook fa-3x"></i>
			<i class="fa fa-google-plus fa-3x"></i>
			<i class="fa fa-twitter fa-3x"></i>
			<i class="fa fa-youtube-play fa-3x"></i>
		</div>
	</div>
</div>
	
</div>
</footer>