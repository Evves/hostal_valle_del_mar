<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<?php include "includes/header.php"; ?>

<div class="container-fluid">
	<div class="row portadas padd ">
		<div class="col-md-12">
			<div class="col-md-6 mensajeBienvenida">
				<h1>Bienvenido a <small>Hostal Valles del Mar</small></h1>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis cumque ex delectus quasi similique. Consectetur placeat qui illo vitae beatae aliquid modi neque, corrupti necessitatibus consequatur, recusandae, molestias commodi quas.</p>
				<button class="btn btn-danger btn-lg">Quiero Registrarme!</button>
			</div>
			
			<div class="col-md-4 col-md-offset-2 cont-form-login ">
				<h1>Login.</h1>
				<form action="#" method="POST" class=" form-login" role="form">
				
					<div class="form-group">
						<label class="sr-only" for="">Rut</label>
						<input type="text" class="form-control" id="txtrut" placeholder="Tu rut">
					</div>
					<div class="form-group">
						<label class="sr-only" for="">Password</label>
						<input type="password" class="form-control" id="txtcontrasena" placeholder="">
					</div>				
				
					<button type="submit" class="btn btn-primary">Submit</button>
				</form>
			</div>	
		</div>
	</div>

	<div class="row pasosreservas padd text-center ">
		<div class="col-xs-6 col-md-3">
			<i class="fa fa-circle-o fa-3x"></i>
			<h3>Logeate.</h3>
		</div>
		<div class="col-xs-6 col-md-3">
			<i class="fa fa-circle-o fa-3x"></i>
			<h3>Haz tu reserva.</h3>
		</div>
		<div class="col-xs-6 col-md-3">
			<i class="fa fa-circle-o fa-3x"></i>
			<h3>Paga tu reserva (50 %).</h3>
		</div>
		<div class="col-xs-6 col-md-3">
			<i class="fa fa-circle-o fa-3x"></i>
			<h3>Reserva lista.</h3>
		</div>
	</div>

	<div class="row quienesSomos padd " id="somos">
		<h1 class="text-center">Quienes Somos.</h1>		
		<div class="col-md-8 col-md-offset-2 ">
			<p class="text-justify"><i class="fa fa-quote-left fa-3x"></i>  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum, suscipit, consectetur ut inventore possimus dolor tempore sint aliquam assumenda facere eveniet eos necessitatibus consequuntur error! Natus nisi non fugit, dolorem.  <i class="fa fa-quote-right fa-3x"></i></p>
		</div>		
	</div>

	<div class="row galeria"></div>

	<div class="row ubicacion ">
		<h1 class="text-center">Ubicanos <small>en el mapa</small></h1>		
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1729.3664493120123!2d-71.25220374723077!3d-29.90079602016911!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0000000000000000%3A0x5809da234cf9247c!2sHotel+y+Hostal+Valles+del+Mar!5e0!3m2!1ses!2scl!4v1414124240956" width="100%" height="400" frameborder="0" style="border:0"></iframe>
	</div>

	<div class="row contactanos padd">
		<div class="col-md-4">
			<h1>Nuestros Datos.</h1>
			<div class="col-xs-6 col-md-6">
				<address>
				  <strong>Twitter, Inc.</strong><br>
				  795 Folsom Ave, Suite 600<br>
				  San Francisco, CA 94107<br>
				  <abbr title="Phone">P:</abbr> (123) 456-7890
				</address>
			</div>
			<div class="col-xs-6 col-md-6">
				<address>
				  <strong>Twitter, Inc.</strong><br>
				  795 Folsom Ave, Suite 600<br>
				  San Francisco, CA 94107<br>
				  <abbr title="Phone">P:</abbr> (123) 456-7890
				</address>
			</div>
		</div>
		<div class="col-md-8 cont-form ">
				<h1 class="text-center">Nos da gusta saber de ti.</h1>
			<form action="#" method="POST" class="form-contacto" role="form">
			
				<div class="form-group">
					<label class="sr-only" for="">Nombre:</label>
					<input type="text" class="form-control" id="txtnombre" placeholder="tu nombre">
				</div>
				<div class="form-group">
					<label class="sr-only" for="">Apellidos</label>
					<input type="text" class="form-control" id="txtapellido" placeholder="tus apellidos">
				</div>
				<div class="form-group">
					<label class="sr-only" for="">Celular</label>
					<input type="number" class="form-control" id="txtcelular" placeholder="ej: +56987654321">
				</div>
				<div class="form-group">
					<label class="sr-only" for="">Email</label>
					<input type="email" class="form-control" id="txtemail" placeholder="ejemplo@ejemplo.cl">
				</div>
				<div class="form-group">
					<label class="sr-only" for="">mensaje</label>
					<textarea class=" form-control" name="mensaje" id="txtmensaje" cols="30" rows="10" placeholder="Dejanos tu mensaje "></textarea>
				</div>
			
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>
		</div>
	</div>
	
</div>
<?php include "includes/footer.php"; ?>

<?php include "includes/script.php"; ?>
</body>
</html>