<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Area Clientes - Hostal Valles del Mar</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top hidden-xs">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a data-toggle="modal"  href="#MActualizarDatos" >Actualizar Datos</a></li>
				<li><a href="#">Realizar Reserva</a></li>
				<li><a href="#"> / </a></li>
				<li><a href="#">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>

<div class="container-fluid">
	
	<div class="row reserva_realizada padd">
		<h1 class="text-center">No tienes reservas.</h1>
		<h3 class="text-center">
			<small>Quieres realizar una reserva AHORA?</small>
		</h3>
		<button class="center-block btn btn-lg btn-danger">Realizar Reserva.</button>
	</div>
</div>


<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>


<!-- Ventanas modales -->
<div class="modal fade" id="MActualizarDatos">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Modal title</h4>
			</div>
			<div class="modal-body">
				<h1>datos del cliente cargados.</h1>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->




</body>
</html>