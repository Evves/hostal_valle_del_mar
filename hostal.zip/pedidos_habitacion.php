<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="creacion_menus.php">Crear Menus</a></li>
				<li><a href="pedidos_habitacion.php">Pedido Servicios</a></li>
				<li><a href="inventarios.php">inventario</a></li>
				<li><a href="estadisticas.php">Estadisticas</a></li>
				<li class="dropdown">
		          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Solicitudes <span class="caret"></span></a>
		          <ul class="dropdown-menu" role="menu">
		            <li><a href="#MMantencion">Mantencion</a></li>
		            <li><a href="MReparacion">Reparacion</a></li>
		          </ul>
		        </li>
		        <li><a href="empleados.php">Empleados</a></li>
				<li><a href="#"> / </a></li>
				<li><a href="logout.php">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>

<div class="container-fluid">
	<div class="row busqueda_habitacion padd">
		<h1>Busqueda por habitacio</h1>
		<div class="col-md-4">
			<select class="form-control"name="Numhab" id="sltnumhabitacion">
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
			</select>
		</div>
		<button class="btn btn-danger">Cargar Datos..</button>
	</div>	

	<div class="row datos_habitacion padd">
		<h1>Datos de la Habitacion</h1>
		<div class="table-responsive">
		  <table class="table table-striped">
		    <tr>
		    	<td>N°</td>
		    	<td>Nombre Servicio</td>
		    	<td>cantidad</td>
		    	<td>total</td>
		    </tr>
		    <tr>
		    	<td>1</td>
		    	<td>nombre1</td>
		    	<td>1</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>2</td>
		    	<td>nombre2</td>
		    	<td>2</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>3</td>
		    	<td>nombre3</td>
		    	<td>3</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>4</td>
		    	<td>nombre4</td>
		    	<td>4</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>5</td>
		    	<td>nombre5</td>
		    	<td>5</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>6</td>
		    	<td>nombre6</td>
		    	<td>6</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>7</td>
		    	<td>nombre7</td>
		    	<td>7</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>8</td>
		    	<td>nombre8</td>
		    	<td>8</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>9</td>
		    	<td>nombre9</td>
		    	<td>9</td>
		    	<td>2000</td>
		    </tr>
		    <tr>
		    	<td>10</td>
		    	<td>nombre10</td>
		    	<td>10</td>
		    	<td>2000</td>
		    </tr>
		  </table>
		</div>
	</div>

	<div class="agregar_pedido ">
		<div class="col-md-12 padd">
            <h1>Nuevo Pedido</h1>
            <div class="col-md-2">
            	<label for="" class="checkbox-inline">
            		<input type="checkbox" id="cbdesayuno">
					Desayuno
            	</label>            	
            </div>
            <div class="col-md-2">
            	<label for="" class="checkbox-inline">
            		<input type="checkbox" id="cbdesayuno">
					Almuerzo
            	</label>            	
            </div>
            <div class="col-md-2">
            	<label for="" class="checkbox-inline">
            		<input type="checkbox" id="cbdesayuno">
					Once
            	</label>            	
            </div>
            <div class="col-md-2">
            	<label for="" class="checkbox-inline">
            		<input type="checkbox" id="cbdesayuno">
					Cena
            	</label>            	
            </div>
            <div class="col-md-2">
            	<label for="" class="checkbox-inline">
            		<input type="checkbox" id="cbdesayuno">
					Cena Romantica
            	</label>            	
            </div>
            <div class="col-md-2">
            	<label for="" class="checkbox-inline">
            		<input type="checkbox" id="cbdesayuno">
					Spa
            	</label>            	
            </div>            
        </div>

        <div class="row padd">
        	<h3>N° personas</h3>
        	<select name="sltnpersonas" id="npersonas" class="form-control	">
        		<option value="1">1</option>
        		<option value="2">2</option>
        		<option value="3">3</option>
        		<option value="4">4</option>
        		<option value="5">5</option>
        		<option value="6">6</option>
        		<option value="7">7</option>
        		<option value="8">8</option>
        		<option value="9">9</option>
        		<option value="10">10</option>
        	</select>
        </div>
	</div>

	<div class="row padd ">
		<div class="col-md-12">
			<div class="col-md-6"><button class="btn btn-warning btn-lg">cargar</button></div>
			<div class="col-md-6"><button class="btn btn-danger btn-lg">Imprimir</button></div>
		</div>
	</div>

</div>

<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>
</body>
</html>