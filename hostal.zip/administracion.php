<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link href='css/fullcalendar.min.css' rel='stylesheet' />
<link href='css/fullcalendar.print.css' rel='stylesheet' media='print' />
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top hidden-xs">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="creacion_menus.php">Crear Menus</a></li>
				<li><a href="pedidos_habitacion.php">Pedido Servicios</a></li>
				<li><a href="inventarios.php">inventario</a></li>
				<li><a href="estadisticas.php">Estadisticas</a></li>
				<li class="dropdown">
		          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Solicitudes <span class="caret"></span></a>
		          <ul class="dropdown-menu" role="menu">
		            <li><a href="#MMantencion" data-toggle="modal">Mantencion</a></li>
		            <li><a href="#MReparacion" data-toggle="modal">Reparacion</a></li>
		          </ul>
		        </li>
		        <li><a href="empleados.php">Empleados</a></li>
				<li><a href="#"> / </a></li>
				<li><a href="logout.php">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>


<div class="container-fluid">
	<div class="row " id="calendario"></div>

	<div class="row reserva_telefono ">
		<div class="col-md-6 busqueda_cliente padd">
			<h2>Busqueda: </h2>
			<input class="" type="text" id="txtrutcliente" placeholder="rut del cliente">
			<a class="btn btn-danger" data-toggle="modal" href='#cliente_nuevo'><i class="fa fa-search"></i> Buscar Cliente</a>
		</div>
		<div class="col-md-6 datos_cliente padd">
		<div class="">
			<div class="col-sm-12">
                <div class="col-xs-12 col-sm-8">
                    <h2>Elvis Muñoz Gallardo.</h2>
                    <p><strong>Direccion: </strong> Av. españa 1040</p>
                    <p><strong>Correo: </strong>Example@example.cl</p>
                    <p><strong>Fecha Nac: </strong> 04/04/1991</p>
                </div>             
                <div class="col-xs-12 col-sm-4 text-center">
                    <figure>
                        <img src="http://www.localcrimenews.com/wp-content/uploads/2013/07/default-user-icon-profile.png" alt="" class="img-circle img-responsive">
                    </figure>
                </div>
            </div>
            <div class="col-xs-12 divisor text-center">
                <div class="col-xs-12 col-sm-4 emphasis">
                    <h2><strong> 23</strong></h2>                    
                    <p><small>Años</small></p>
                </div>
                <div class="col-xs-12 col-sm-4 emphasis">
                    <h2><strong>Masculino</strong></h2>                    
                    <p><small>Genero</small></p>
                </div>
                <div class="col-xs-12 col-sm-4 emphasis">
                    <h2><strong>87654321</strong></h2>                    
                    <p><small>Telefono</small></p>
                </div>
            </div>
		</div>

			
		</div>
	</div>
	<div class="row fechas_reserva">
        <div class="col-md-12">
            <h1>Realizar Reserva</h1>
            <h3>Selecciona la fecha de llegada.</h3>
            
            <div class="col-md-6">
                <h2>Check-IN</h2>
                <input type="text" id="checkin" class="input-lg">
            </div>
            <div class="col-md-6">
                <h2>Check-Out</h2>
                <input type="text" id="checkout" class="input-lg">
            </div>
        </div>
    </div>

    <div class="row datos_reserva">
        <div class="col-md-6 ">
            <h1>Datos de habitacion</h1>
            <div class="form-group ">
                <label class="col-sm-2 control-label" for="txttipohabitacion">Seleccione tipo habitacion</label>
                <div class="col-sm-10">
                  <input class="form-control" type="text" id="txttipohabitacion">
                </div>
            </div>
            <div class="form-group ">
                <label class="col-sm-2 control-label" for="txtnumhabitacion">N° habitacion</label>
                <div class="col-sm-10">
                  <input class="form-control" type="number" id="txtnumhabitacion">
                </div>
            </div>
            <div class="form-group ">
                <label class="col-sm-2 control-label" for="txtcamasadicionales">Camas adicionales</label>
                <div class="col-sm-10">
                  <input class="form-control" type="number" id="txtcamasadicionales">
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <h1>datos servicios</h1>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="desayuno">
                Desayuno
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="almuerzo">
                Almuerzo
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="once">
                Once
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="cena">
                Cena
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="lavanderia">
                Lavanderia
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="spa">
                Spa
              </label>
            </div>
        </div>
    </div>
	<div class="col-md-6">
        <p>Servicio a la habitacion solo para el primer dia*</p>

        <h4>Describa si desea alguna atencion especial a la hora de su llegada.</h4>
        <textarea name="txtservicioespecial" id="txtservicioespecial" cols="85" rows="8"></textarea>
        <br>
        <button class="bt btn-lg btn-danger">Realizar Reserva</button>
    </div>


</div>





<!-- ventanas modales -->

<!-- ventana modal de formuladio de nuevo cliente por registrar -->
<div class="modal fade" id="cliente_nuevo">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Nuevo Cliente</h4>
			</div>
			<div class="modal-body">
				<form action="" method="POST" role="form">
					<legend>Form title</legend>
				
					<div class="form-group">
						<label for="">Nombres</label>
						<input type="text" class="form-control" id="" placeholder="Elvis edgardo">
					</div>
					<div class="form-group">
						<label for="">Apellido Paterno</label>
						<input type="text" class="form-control" id="" placeholder="muñoz">
					</div>
					<div class="form-group">
						<label for="">Apellido Materno</label>
						<input type="text" class="form-control" id="" placeholder="gallardo">
					</div>
					<div class="form-group">
						<label for="">Rut</label>
						<input type="text" class="form-control disable" id="" placeholder="17892519-9">
					</div>
				</form>
				p{**Debe avisar al cliente que se encuentra en linea que debe ingresar al sitio web y actualizar sus datos.}
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Guardar</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->




<!-- ventana modal de solicitud de mantencion -->
<div class="modal fade" id="MMantencion">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Mantencion</h4>
			</div>
			<div class="modal-body">
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- ventana modal de solicitud de reparacion-->
<div class="modal fade" id="MReparacion">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Solicitud de Reparacion</h4>
			</div>
			<div class="modal-body">
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>

<script src='js/moment.min.js'></script>
<script src='js/fullcalendar.min.js'></script>
<script src="js/jquery-ui.js"></script>



<script>
$(function() {
    $( "#checkin" ).datepicker();
});
/* funcion para mostrar el calendario de checkout*/
$(function() {
    $( "#checkout" ).datepicker();
});
	$(document).ready(function() {
		
		$('#calendario').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,basicWeek,basicDay'
			},
			defaultDate: '2014-11-05',
			editable: true,
			eventLimit: true, // allow "more" link when too many events
			events: [
				{
					title: 'All Day Event',
					start: '2014-09-01'
				},
				{
					title: 'Long Event',
					start: '2014-09-07',
					end: '2014-09-10'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2014-09-09T16:00:00'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2014-09-16T16:00:00'
				},
				{
					title: 'Conference',
					start: '2014-09-11',
					end: '2014-09-13'
				},
				{
					title: 'Meeting',
					start: '2014-09-12T10:30:00',
					end: '2014-09-12T12:30:00'
				},
				{
					title: 'Lunch',
					start: '2014-09-12T12:00:00'
				},
				{
					title: 'Meeting',
					start: '2014-09-12T14:30:00'
				},
				{
					title: 'Happy Hour',
					start: '2014-09-12T17:30:00'
				},
				{
					title: 'Dinner',
					start: '2014-09-12T20:00:00'
				},
				{
					title: 'Birthday Party',
					start: '2014-09-13T07:00:00'
				},
				{
					title: 'Click for Google',
					url: 'http://google.com/',
					start: '2014-09-28'
				},
				{
					title: 'Presentacion Taller de proyectos informaticos II',
					url:'www.hotalvallesdelmar.esy.es',
					start: '2014-11-05T18:45:00'
				}

			]
		});
		
	});

</script>
</body>
</html>