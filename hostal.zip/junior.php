<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="logout.php">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>

<div class="container-fluid">
	<div class="row solicitudes_alertas padd">
		<div class="alert alert-danger">		
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<h1><span class="label label-default">Nueva</span> Solicitud de Reparacion </h1>
			<h3>Habitacion: <small>N° 13</small></h3>
			<p>El lavamanos se encuentra tapado</p>
			<button class="btn btn-warning btn-lg">Aceptar</button>
		</div>

		<div class="alert alert-success">		
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<h1><span class="label label-default">Nueva</span> Solicitud de Reparacion</h1>
			<h3>Habitacion: <small>N° 14</small></h3>
			<p>Puerda del baño se encuentra atascada</p>
			<button class="btn btn-default btn-lg">Hecho</button>
		</div>
	</div>
</div><!-- fin container fluid -->

<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>
</body>
</html>