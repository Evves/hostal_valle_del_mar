<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top hidden-xs">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="creacion_menus.php">Crear Menus</a></li>
				<li><a href="pedidos_habitacion.php">Pedido Servicios</a></li>
				<li><a href="inventarios.php">inventario</a></li>
				<li><a href="estadisticas.php">Estadisticas</a></li>
				<li class="dropdown">
		          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Solicitudes <span class="caret"></span></a>
		          <ul class="dropdown-menu" role="menu">
		            <li><a href="#MMantencion" data-toggle="modal">Mantencion</a></li>
		            <li><a href="#MReparacion" data-toggle="modal">Reparacion</a></li>
		          </ul>
		        </li>
		        <li><a href="empleados.php">Empleados</a></li>
				<li><a href="#"> / </a></li>
				<li><a href="logout.php">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>




<div class="container-fluid">
	
	<div class="row nuevo_empleado padd">
		<div class="col-md-6">
			<h1><span class="label label-default">Tipo</span> Cargo   <button class="btn btn-success pull-right">Agregar Nuevo Rol</button></h1>
			<select name="cargo" id="" class="form-control">
				<option value="0">Seleccione...</option>
				<option value="mucama">Mucama</option>
				<option value="junior">Junior</option>
				<option value="coninero">Cocinero(a)</option>
			</select>

			<br>

			<h1><span class="label label-default">Datos</span> del nuevo cliente</h1>
			
			<div class="table-responsive">
				<table class="table ">
					<tbody>
						<tr>
							<td>Nombre</td>
							<td>
								<input type="text" placeholder="Nombre empleado">
							</td>
						</tr>
						<tr>
							<td>Apellido paterno</td>
							<td>
								<input type="text" placeholder="Apellido Paterno">
							</td>
						</tr>
						<tr>
							<td>Apellido materno</td>
							<td>
								<input type="text" placeholder="Apellido Materno">
							</td>
						</tr>
						<tr>
							<td>Rut</td>
							<td>
								<input type="text" placeholder="Ej: 17892519-9">
							</td>
						</tr>
						<tr>
							<td>Fecha Nace</td>
							<td>
								<input type="text" placeholder="ej">
							</td>
						</tr>
						<tr>
							<td>Direccion</td>
							<td>
								<input type="text" placeholder="ej: av españa 1024">
							</td>
						</tr>
						<tr>
							<td>Genero</td>
							<td>
								<select name="genero" id="sltgenero">
									<option value="masculino">Masculino</option>
									<option value="femenino">Femenino</option>
								</select>
							</td>
						</tr>
						<tr>
							<td>Estado</td>
							<td>
								<div class="btn-group">
								  <button type="button" class="btn btn-danger">Desactivado</button>
								  <button type="button" class="btn btn-success">Activo</button>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<button class="btn btn-danger">Agregar Empleado</button>
		</div>

		<div class="col-md-6">
			<h1><span class="label label-default">Recuerda</span> que....</h1>
			<div class="alert alert-danger" role="alert">
				<p>Las contraseñas para los empleados son generadas automaticamente por el sistema</p>
			</div>
			<h1><span class="label label-default">Lista</span> Empleados Activos</h1>
			<div class="table-responsive">
			  <table class="table table-striped">
			    <tr>
			    	<td>N°</td>
			    	<td>Nombre Completo</td>
			    	<td>Cargo</td>
			    	<td>Fecha Inicio</td>
			    	<td>Modificacion</td>
			    	<td>Dar de baja</td>
			    </tr>
			    <tr>
			    	<td>1</td>
			    	<td>Maximiliano ariel lillo garcia</td>
			    	<td>mucamo</td>
			    	<td>20/10/2014</td>
			    	<td><i class="fa fa-pencil text-warning"></i> <a href="#Meditar" data-toggle="modal">Editar</a></td>
			    	<td class="text-center"><a href="#Meliminar" data-toggle="modal"><i class="fa fa-times-circle fa-2x text-danger "></i></a></td>
			    </tr>
			    <tr>
			    	<td>1</td>
			    	<td>Elvis Edgardo muñoz gallar</td>
			    	<td>junior</td>
			    	<td>22/10/2014</td>
			    	<td><i class="fa fa-pencil text-warning"></i> <a href="#Meditar" data-toggle="modal">Editar</a></td>
			    	<td class="text-center"><a href="#Meliminar" data-toggle="modal"><i class="fa fa-times-circle fa-2x text-danger "></i></a></td>
			    </tr>
			    <tr>
			    	<td>1</td>
			    	<td>maria eugenia larrain Mcclaren</td>
			    	<td>mucama</td>
			    	<td>24/10/2014</td>
			    	<td><i class="fa fa-pencil text-warning"></i> <a href="#Meditar" data-toggle="modal">Editar</a></td>
			    	<td class="text-center"><a href="#Meliminar" data-toggle="modal"><i class="fa fa-times-circle fa-2x text-danger "></i></a></td>
			    </tr>
			    <tr>
			    	<td>1</td>
			    	<td>Maximiliano ariel lillo garcia</td>
			    	<td>cocinero</td>
			    	<td>26/10/2014</td>
			    	<td><i class="fa fa-pencil text-warning"></i> <a href="#Meditar" data-toggle="modal">Editar</a></td>
			    	<td class="text-center"><a href="#Meliminar" data-toggle="modal"><i class="fa fa-times-circle fa-2x text-danger "></i></a></td>
			    </tr>
			    
			  </table>
			</div>
		</div>
	</div>
	



</div><!-- fin container fluid -->


<!-- ventanas modales -->


<!-- ventana modal modificacion empleado -->
<div class="modal fade" id="Meditar">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Modificacion datos del empleado</h4>
			</div>
			<div class="modal-body">
				<div class="table-responsive">
				<table class="table ">
					<tbody>
						<tr>
							<td>Nombre</td>
							<td>
								<input type="text" placeholder="Nombre empleado">
							</td>
						</tr>
						<tr>
							<td>Apellido paterno</td>
							<td>
								<input type="text" placeholder="Apellido Paterno">
							</td>
						</tr>
						<tr>
							<td>Apellido materno</td>
							<td>
								<input type="text" placeholder="Apellido Materno">
							</td>
						</tr>
						<tr>
							<td>Rut</td>
							<td>
								<input type="text" placeholder="Ej: 17892519-9">
							</td>
						</tr>
						<tr>
							<td>Fecha Nace</td>
							<td>
								<input type="text" placeholder="ej">
							</td>
						</tr>
						<tr>
							<td>Direccion</td>
							<td>
								<input type="text" placeholder="ej: av españa 1024">
							</td>
						</tr>
						<tr>
							<td>Genero</td>
							<td>
								<select name="genero" id="sltgenero">
									<option value="masculino">Masculino</option>
									<option value="femenino">Femenino</option>
								</select>
							</td>
						</tr>
						<tr>
							<td>Estado</td>
							<td>
								<div class="btn-group">
								  <button type="button" class="btn btn-danger">Desactivado</button>
								  <button type="button" class="btn btn-success">Activo</button>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- ventana modal eliminacion empleado -->
<div class="modal fade" id="Meliminar">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Realmente deseas dar de baja a este empleado</h4>
			</div>
			<div class="modal-body">
				<div class="datos_cliente ">
		
					<div class="col-sm-12">
		                <div class="col-xs-12 col-sm-8">
		                    <h2>Elvis Muñoz Gallardo.</h2>
		                    <p><strong>Direccion: </strong> Av. españa 1040</p>
		                    <p><strong>Correo: </strong>Example@example.cl</p>
		                    <p><strong>Fecha Nac: </strong> 04/04/1991</p>
		                </div>             
		                <div class="col-xs-12 col-sm-4 text-center">
		                    <figure>
		                        <img src="http://www.localcrimenews.com/wp-content/uploads/2013/07/default-user-icon-profile.png" alt="" class="img-circle img-responsive">
		                    </figure>
		                </div>
		            </div>
		            <div class="col-xs-12 divisor text-center">
		                <div class="col-xs-12 col-sm-4 emphasis">
		                    <h2><strong> 23</strong></h2>                    
		                    <p><small>Años</small></p>
		                </div>
		                <div class="col-xs-12 col-sm-4 emphasis">
		                    <h2><strong>Masculino</strong></h2>                    
		                    <p><small>Genero</small></p>
		                </div>
		                <div class="col-xs-12 col-sm-4 emphasis">
		                    <h2><strong>87654321</strong></h2>                    
		                    <p><small>Telefono</small></p>
		                </div>
		            </div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
				<button type="button" class="btn btn-primary">Dar de baja</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>
</body>
</html>