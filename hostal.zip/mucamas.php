<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="logout.php">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>



<div class="container-fluid">
	<div class="row solicitudes_alertas padd">
		<div class="alert alert-danger">		
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<h1><span class="label label-default">Nueva</span> Solicitud de Limpieza (Check-out)</h1>
			<h3>Habitacion: <small>N° 13</small></h3>
		
			<button class="btn btn-warning btn-lg">Aceptar</button>
		</div>

		<div class="alert alert-success">		
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<h1><span class="label label-default">Nueva</span> Solicitud de Limpieza (Check-out)</h1>
			<h3>Habitacion: <small>N° 13</small></h3>
		
			<button class="btn btn-default btn-lg">Hecho</button>
		</div>
	</div>

	<div class="row padd">
		<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
			<div class="panel panel-default">
				<div class="panel-heading" role="tab" id="headingOne">
					<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
					  Revision Inventario.
					</a>
					</h4>
				</div>
				<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
					<div class="panel-body">
						
					</div>
				</div>
			</div>
		</div>
		<div class="panel panel-default">
			<div class="panel-heading" role="tab" id="headingTwo">
			  <h4 class="panel-title">
			    <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
			      Limpieza Diaria.
			    </a>
			  </h4>
			</div>
		<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
		  <div class="panel-body">

			<div class="row padd">
				<div class="col-xs-12">
					<h1>Seleccione Habitacion: </h1>		
				</div>
				<div class="col-xs12 col-md-12">
					<select name="numhabitacion" id="numhabitacion" class="form-control">
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
					</select>
				</div>
			</div><!-- fin row seleccion numero de habitacion -->

					<div class="row lista_inventario padd">
						<div class="table-responsive ">
						<h1><span class="label label-default">Lista</span> de Objetos</h1>
						  <table class="table table-striped">
						    <tr>
						    	<td>N°</td>
						    	<td>Nombre objeto</td>
						    	<td>Cantidad</td>
						    	<td>Estado</td>
						    	<td>Editar</td>
						    	<td>Eliminar</td>
						    </tr>
						    <tr>
						    	<td>1</td>
						    	<td>lampara</td>
						    	<td>4</td>
						    	<td class="text-success"><i class="fa fa-check-square-o"></i></td>
						    	<td><button class="btn btn-xs btn-warning center-block"><i class="fa fa-pencil"></i></button></td>
						    	<td><button class="btn btn-xs btn-danger center-block"><i class="fa fa-times"></i></button></td>
						    </tr>
						    <tr>
						    	<td>1</td>
						    	<td>lampara</td>
						    	<td>4</td>
						    	<td class="text-success"><i class="fa fa-check-square-o"></i></td>
						    	<td><button class="btn btn-xs btn-warning center-block"><i class="fa fa-pencil"></i></button></td>
						    	<td><button class="btn btn-xs btn-danger center-block"><i class="fa fa-times"></i></button></td>
						    </tr>
						  </table>
						</div>
				  	</div>

					<div class="row solicitud_reparacion_mucama padd">
						<h1>Que <small>Sucede?</small></h1>
						<p>Encontraste algun desperfecto? envia una solicitud de reparacion.</p>
						<textarea name="" id="" cols="30" rows="10" class="form-control"></textarea>
						<button class="btn btn-lg btn-danger">Enviar Solicitud</button>
					</div>

				</div>
			</div>
		</div>
	</div>
</div><!-- fin container fluid -->

<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>
</body>
</html>