<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="creacion_menus.php">Crear Menus</a></li>
				<li><a href="pedidos_habitacion.php">Pedido Servicios</a></li>
				<li><a href="inventarios.php">inventario</a></li>
				<li><a href="estadisticas.php">Estadisticas</a></li>
				<li class="dropdown">
		          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Solicitudes <span class="caret"></span></a>
		          <ul class="dropdown-menu" role="menu">
		            <li><a href="#MMantencion">Mantencion</a></li>
		            <li><a href="MReparacion">Reparacion</a></li>
		          </ul>
		        </li>
		        <li><a href="empleados.php">Empleados</a></li>
				<li><a href="#"> / </a></li>
				<li><a href="logout.php">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>

<div class="container-fluid">
	<div class="row padd">
		<div class="col-xs-12">
			<h1>Seleccione Habitacion: </h1>		
		</div>
		<div class="col-xs12 col-md-12">
			<select name="numhabitacion" id="numhabitacion" class="form-control">
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
			</select>
		</div>
	</div><!-- fin row seleccion numero de habitacion -->

	<div class="row lista_inventario padd">
		<div class="table-responsive col-md-6">
		<h1><span class="label label-default">Lista</span> de Objetos</h1>
		  <table class="table table-striped">
		    <tr>
		    	<td>N°</td>
		    	<td>Nombre objeto</td>
		    	<td>Cantidad</td>
		    	<td>Estado</td>
		    	<td>Editar</td>
		    	<td>Eliminar</td>
		    </tr>
		    <tr>
		    	<td>1</td>
		    	<td>lampara</td>
		    	<td>4</td>
		    	<td class="text-success"><i class="fa fa-check-square-o"></i></td>
		    	<td><button class="btn btn-xs btn-warning center-block"><i class="fa fa-pencil"></i></button></td>
		    	<td><button class="btn btn-xs btn-danger center-block"><i class="fa fa-times"></i></button></td>
		    </tr>
		    <tr>
		    	<td>1</td>
		    	<td>lampara</td>
		    	<td>4</td>
		    	<td class="text-success"><i class="fa fa-check-square-o"></i></td>
		    	<td><button class="btn btn-xs btn-warning center-block"><i class="fa fa-pencil"></i></button></td>
		    	<td><button class="btn btn-xs btn-danger center-block"><i class="fa fa-times"></i></button></td>
		    </tr>
		  </table>
		</div>
		<div class="table-responsive col-md-6 nuevo_objeto">
			<h1><span class="label label-default">Nuevo</span> Objeto</h1>
		  	<table class="table table-striped">
			    <tr>
			    	<td>Nombre objeto</td>
			    	<td>Cantidad</td>
			    	<td></td>
			    </tr>
			    <tr>
			    	<td>cubrecamas</td>
			    	<td>2</td>
			    	<td class="text-success"><i class="fa fa-check-square-o"></i></td>
			    </tr>
			    <tr>
			    	<td><input type="text" placeholder="Nombre obj"></td>
			    	<td><input type="number"></td>
			    	<td><button class="btn btn-success btn-xs">Agregar</button></td>
			    </tr>
		  	</table>
		  	<button class="btn btn-success pull-right"><i class="fa fa-plus"></i></button>
		</div>
		<div class="col-md-12"><button class="btn center-block btn-danger">Guardar Inventario</button></div>
	</div>




</div><!-- fin div container fluid -->

<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>
</body>
</html>