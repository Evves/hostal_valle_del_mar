<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
    <link rel="stylesheet" href="css/jquery-ui.css">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top hidden-xs">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#">Actualizar Datos</a></li>
				<li><a href="#">Realizar Reserva</a></li>
				<li><a href="#"> / </a></li>
				<li><a href="#">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>


<div class="container-fluid">

    <div class="row fechas_reserva">
        <div class="col-md-12">
            <h1>Realizar Reserva</h1>
            <h3>Selecciona la fecha de llegada.</h3>
            
            <div class="col-md-6">
                <h2>Check-IN</h2>
                <input type="text" id="checkin" class="input-lg">
            </div>
            <div class="col-md-6">
                <h2>Check-Out</h2>
                <input type="text" id="checkout" class="input-lg">
            </div>
        </div>
    </div>

    <div class="row datos_reserva">
        <div class="col-md-6">
            <h1>Datos de habitacion</h1>
            <div class="form-group ">
                <label class="col-sm-2 control-label" for="txttipohabitacion">Seleccione tipo habitacion</label>
                <div class="col-sm-10">
                  <input class="form-control" type="text" id="txttipohabitacion">
                </div>
            </div>
            <div class="form-group ">
                <label class="col-sm-2 control-label" for="txtnumhabitacion">N° habitacion</label>
                <div class="col-sm-10">
                  <input class="form-control" type="number" id="txtnumhabitacion">
                </div>
            </div>
            <div class="form-group ">
                <label class="col-sm-2 control-label" for="txtcamasadicionales">Camas adicionales</label>
                <div class="col-sm-10">
                  <input class="form-control" type="number" id="txtcamasadicionales">
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <h1>datos servicios</h1>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="desayuno">
                Desayuno
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="almuerzo">
                Almuerzo
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="once">
                Once
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="cena">
                Cena
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="lavanderia">
                Lavanderia
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="spa">
                Spa
              </label>
            </div>
        </div>
    </div>
	<div class="col-md-6">
        <p>Servicio a la habitacion solo para el primer dia*</p>

        <h4>Describa si desea alguna atencion especial a la hora de su llegada.</h4>
        <textarea name="txtservicioespecial" id="txtservicioespecial" cols="85" rows="8"></textarea>
        <br>
        <button class="bt btn-lg btn-danger">Realizar Reserva</button>
    </div>

</div>

<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>
<script src="js/jquery-ui.js"></script>

<script>
/* funcion para mostrar el calendario de checkin*/
$(function() {
    $( "#checkin" ).datepicker();
});
/* funcion para mostrar el calendario de checkout*/
$(function() {
    $( "#checkout" ).datepicker();
});
</script>
</body>
</html>