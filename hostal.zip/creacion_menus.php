<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top hidden-xs">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="creacion_menus.php">Crear Menus</a></li>
				<li><a href="pedidos_habitacion.php">Pedido Servicios</a></li>
				<li><a href="inventarios.php">inventario</a></li>
				<li><a href="estadisticas.php">Estadisticas</a></li>
				<li class="dropdown">
		          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Solicitudes <span class="caret"></span></a>
		          <ul class="dropdown-menu" role="menu">
		            <li><a href="#MMantencion">Mantencion</a></li>
		            <li><a href="MReparacion">Reparacion</a></li>
		          </ul>
		        </li>
		        <li><a href="empleados.php">Empleados</a></li>
				<li><a href="#"> / </a></li>
				<li><a href="logout.php">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>

<div class="container-fluid">


	<div class="row menu_semanal padd">
		<ul class="nav nav-tabs" role="tablist" id="myTab">
		  <li role="presentation" class="active"><a href="#lunes" role="tab" data-toggle="tab">LUNES</a></li>
		  <li role="presentation"><a href="#martes" role="tab" data-toggle="tab">MARTES</a></li>
		  <li role="presentation"><a href="#miercoles" role="tab" data-toggle="tab">MIERCOLES</a></li>
		  <li role="presentation"><a href="#jueves" role="tab" data-toggle="tab">JUEVES</a></li>
		  <li role="presentation"><a href="#viernes" role="tab" data-toggle="tab">VIERNES</a></li>
		  <li role="presentation"><a href="#sabado" role="tab" data-toggle="tab">SABADO</a></li>
		  <li role="presentation"><a href="#domingo" role="tab" data-toggle="tab">DOMINGO</a></li>
		</ul>

		<div class="tab-content">

			<div role="tabpanel" class="tab-pane fade in active" id="lunes">
				<div class="col-xs-12 col-md-6">
					<h1>Desayuno</h1>
					<textarea name="" id="lundesayuno" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Almuerzo</h1>
					<textarea name="" id="lunalmuerzo" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Once</h1>
					<textarea name="" id="lunonce" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Cena</h1>
					<textarea name="" id="luncena" cols="50" rows="5"></textarea>
				</div>
			</div>

			
			<div role="tabpanel" class="tab-pane fade" id="martes">
				<div class="col-xs-12 col-md-6">
					<h1>Desayuno</h1>
					<textarea name="" id="Mardesayuno" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Almuerzo</h1>
					<textarea name="" id="Maralmuerzo" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Once</h1>
					<textarea name="" id="Maronce" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Cena</h1>
					<textarea name="" id="Marcena" cols="50" rows="5"></textarea>
				</div>
			</div>


			<div role="tabpanel" class="tab-pane fade" id="miercoles">
				<div class="col-xs-12 col-md-6">
					<h1>Desayuno</h1>
					<textarea name="" id="Mierdesayuno" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Almuerzo</h1>
					<textarea name="" id="Mieralmuerzo" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Once</h1>
					<textarea name="" id="Mieronce" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Cena</h1>
					<textarea name="" id="Miercena" cols="50" rows="5"></textarea>
				</div>
			</div>
			<div role="tabpanel" class="tab-pane fade" id="jueves">
				<div class="col-xs-12 col-md-6">
					<h1>Desayuno</h1>
					<textarea name="" id="Juevdesayuno" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Almuerzo</h1>
					<textarea name="" id="Juevalmuerzo" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Once</h1>
					<textarea name="" id="Juevonce" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Cena</h1>
					<textarea name="" id="Juevcena" cols="50" rows="5"></textarea>
				</div>
			</div>


			<div role="tabpanel" class="tab-pane fade" id="viernes">
				<div class="col-xs-12 col-md-6">
					<h1>Desayuno</h1>
					<textarea name="" id="Vierdesayuno" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Almuerzo</h1>
					<textarea name="" id="Vieralmuerzo" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Once</h1>
					<textarea name="" id="Vieronce" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Cena</h1>
					<textarea name="" id="Viercena" cols="50" rows="5"></textarea>
				</div>
			</div>


			<div role="tabpanel" class="tab-pane fade" id="sabado">
				<div class="col-xs-12 col-md-6">
					<h1>Desayuno</h1>
					<textarea name="" id="Sabdesayuno" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Almuerzo</h1>
					<textarea name="" id="Sabalmuerzo" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Once</h1>
					<textarea name="" id="Sabonce" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Cena</h1>
					<textarea name="" id="Sabcena" cols="50" rows="5"></textarea>
				</div>
			</div>


			<div role="tabpanel" class="tab-pane fade" id="domingo">
				<div class="col-xs-12 col-md-6">
					<h1>Desayuno</h1>
					<textarea name="" id="Domdesayuno" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Almuerzo</h1>
					<textarea name="" id="Domalmuerzo" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Once</h1>
					<textarea name="" id="Domonce" cols="50" rows="5"></textarea>
				</div>
				<div class="col-xs-12 col-md-6">
					<h1>Cena</h1>
					<textarea name="" id="Domcena" cols="50" rows="5"></textarea>
				</div>
			</div>
		</div>
	</div>

	<div class="row padd">
		<div class="col-md-12 ">
			<button class="btn btn-danger"><i class="fa fa-file-pdf-o fa-3x"></i> Imprimir Menu</button>
		</div>		
	</div>
</div>




<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>

<script>
  $(function () {
    $('#myTab a:first').tab('show')
  })
</script>

</body>
</html>