<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Hostal Valles del Mar - HOME</title>
	<?php include "includes/css.php"; ?>
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top">
	<div class="container">
	<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
		<a class="navbar-brand" href="#page-top">Hostal Valles del Mar</a>
		</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="creacion_menus.php">Crear Menus</a></li>
				<li><a href="pedidos_habitacion.php">Pedido Servicios</a></li>
				<li><a href="inventarios.php">inventario</a></li>
				<li><a href="estadisticas.php">Estadisticas</a></li>
				<li class="dropdown">
		          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Solicitudes <span class="caret"></span></a>
		          <ul class="dropdown-menu" role="menu">
		            <li><a href="#MMantencion">Mantencion</a></li>
		            <li><a href="MReparacion">Reparacion</a></li>
		          </ul>
		        </li>
		        <li><a href="empleados.php">Empleados</a></li>
				<li><a href="#"> / </a></li>
				<li><a href="logout.php">Logout.</a></li>				
			</ul>
		</div>
	<!-- /.navbar-collapse -->
	</div>
<!-- /.container-fluid -->
</nav>


<div class="container-fluid">
	
<div class="row estadistica_mes padd">
	<h1>Clientes <small>que nos visitaron este mes</small></h1>
	<div class="col-md-12">
		<h2>Seleccione mes</h2>
		<select name="meses" id="" class="col-md-6">
			<option value="enero">ene</option>
			<option value="febrero">feb</option>
			<option value="marzo">mar</option>
			<option value="abril">abr</option>
			<option value="mayo">may</option>
			<option value="junio">jun</option>
			<option value="julio">jul</option>
			<option value="agosto">agos</option>
			<option value="septiembre">sept</option>
			<option value="octubre">oct</option>
			<option value="noviembre">nov</option>
			<option value="diciemrbre">dic</option></select>
	</div>
	<h1>Noviembre</h1>
	<div class="col-md-12 estadistica_mes_clientes">
		<div class="progress">
			<div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
				40% Turistas
			</div>	
		</div>
		<div class="progress">
			<div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
				60% Empresas
			</div>	
		</div>
		<button class="btn btn-lg btn-danger">Imprimir</button>
		<button class="btn btn-lg btn-warning">Guardar PDF</button>
	</div>
</div>


<div class="row mas_estadisticas padd">
	<div class="col-md-6 col-xs-12">
		<h1>Habitaciones <small>mas ocupadas</small></h1>
		<p>Muestra estadisticas de cuales fueron las habitaciones mas solicitadas</p>
		<button class="btn btn-lg btn-danger">Imprimir PDF</button>
	</div>
	<div class="col-md-6 col-xs-12">
		<h1>Estadisticas <small>Anuales</small></h1>
		<p>Muestra estadisticas anuales tanto de la cantidad de turistas y empresas que se hospedaron</p>
		<button class="btn btn-lg btn-danger">Imprimir PDF</button>
	</div>
</div>

<div class="row historial_estadisticas padd">
	<h1>Historial <small>de estadisticas</small></h1>
	<table class="table table-striped">
	    <tr>
	    	<td>N°</td>
	    	<td>Nombre</td>
	    	<td>ruta</td>
	    	<td>Fecha Creacion</td>
	    </tr>
	    <tr>
	    	<td>1</td>
	    	<td>Estadisticas anuales</td>
	    	<td><a href="#" class="btn btn-success">Abrir</a></td>
	    	<td>20/08/2014</td>
	    </tr>
	    <tr>
	    	<td>2</td>
	    	<td>Estadisticas mes junio</td>
	    	<td><a href="#" class="btn btn-success">Abrir</a></td>
	    	<td>13/06/2014</td>
	    </tr>
	    <tr>
	    	<td>1</td>
	    	<td>Estadisticas habitaciones mas solicitadas</td>
	    	<td><a href="#" class="btn btn-success">Abrir</a></td>
	    	<td>10/04/2014</td>
	    </tr>
	</table>
</div>

</div><!-- fin container fluid -->




<?php include "includes/footer.php"; ?>
<?php include "includes/script.php"; ?>
</body>
</html>